-------------------------------------------------------------------------------
-- telecran.vhd
-- ============
-- Top-level du projet "écran magique" sur DE10-Nano.
--
-- Conventions de nommage (cf. TP FPGA ENSEA — section "Faire clignoter une LED") :
--   i_  : entrées
--   o_  : sorties
--   r_  : registres (assignés dans un process cadencé)
--   s_  : signaux internes
--
-- Cette version suit EXACTEMENT les extraits de code donnés dans le TP
-- (section "Contrôleur HDMI") :
--   i_clk => s_clk_27
--   i_rst_n => s_rst_n
--   o_pixel_en => open
--   o_pixel_address => open
--   o_hdmi_tx_d(23 downto 16) <= std_logic_vector(to_unsigned(s_x_counter, 8));
--   o_hdmi_tx_d(15 downto 8)  <= std_logic_vector(to_unsigned(s_y_counter, 8));
--   o_hdmi_tx_d(7 downto 0)   <= (others => '0');
-------------------------------------------------------------------------------
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

library pll;
use pll.all;

entity telecran is
    port (
        -- FPGA
        i_clk_50 : in std_logic;

        -- HDMI
        io_hdmi_i2c_scl : inout std_logic;
        io_hdmi_i2c_sda : inout std_logic;
        o_hdmi_tx_clk   : out std_logic;
        o_hdmi_tx_d     : out std_logic_vector(23 downto 0);
        o_hdmi_tx_de    : out std_logic;
        o_hdmi_tx_hs    : out std_logic;
        i_hdmi_tx_int   : in std_logic;
        o_hdmi_tx_vs    : out std_logic;

        -- KEY
        i_rst_n : in std_logic;

        -- LEDs
        o_leds      : out std_logic_vector(9 downto 0);
        o_de10_leds : out std_logic_vector(7 downto 0);

        -- Encodeurs
        i_left_ch_a  : in std_logic;
        i_left_ch_b  : in std_logic;
        i_left_pb    : in std_logic;
        i_right_ch_a : in std_logic;
        i_right_ch_b : in std_logic;
        i_right_pb   : in std_logic
    );
end entity telecran;

architecture rtl of telecran is

    -- Composants existants (PLL + config I2C ADV7513)
    component I2C_HDMI_Config
        port (
            iCLK        : in  std_logic;
            iRST_N      : in  std_logic;
            I2C_SCLK    : out std_logic;
            I2C_SDAT    : inout std_logic;
            HDMI_TX_INT : in  std_logic
        );
    end component;

    component pll
        port (
            refclk   : in  std_logic;
            rst      : in  std_logic;
            outclk_0 : out std_logic;
            locked   : out std_logic
        );
    end component;

    -- Résolution 480p
    constant h_res : positive := 720;
    constant v_res : positive := 480;

    -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- --
    -- Signaux internes (préfixe s_)
    -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- --

    -- Horloge et reset produits par la PLL (noms imposés par le TP)
    signal s_clk_27 : std_logic;
    signal s_rst_n  : std_logic;          -- reste à 0 tant que la PLL n'est pas verrouillée

    -- Compteurs pixel (noms imposés par le TP pour la génération de o_hdmi_tx_d)
    signal s_x_counter : natural range 0 to (h_res - 1);
    signal s_y_counter : natural range 0 to (v_res - 1);

begin

    -- LEDs éteintes (utilisées plus tard pour afficher la valeur encodeur)
    o_leds      <= (others => '0');
    o_de10_leds <= (others => '0');

    -- =======================================================================
    -- PLL : 50 MHz -> 27 MHz (pixel clock pour le 480p)
    -- s_rst_n = locked : le reset reste actif tant que la PLL n'est pas
    --                    verrouillée.
    -- =======================================================================
    pll0 : component pll
        port map (
            refclk   => i_clk_50,
            rst      => not(i_rst_n),
            outclk_0 => s_clk_27,
            locked   => s_rst_n
        );

    -- =======================================================================
    -- Configuration I2C de l'ADV7513 (480p)
    -- =======================================================================
    I2C_HDMI_Config0 : component I2C_HDMI_Config
        port map (
            iCLK        => i_clk_50,
            iRST_N      => i_rst_n,
            I2C_SCLK    => io_hdmi_i2c_scl,
            I2C_SDAT    => io_hdmi_i2c_sda,
            HDMI_TX_INT => i_hdmi_tx_int
        );

    -- =======================================================================
    -- Contrôleur HDMI (instanciation conforme au TP)
    --   "Utilisez l'horloge et le reset produits par la PLL"
    --   "Certains signaux ne sont pas utilisés ici"
    -- =======================================================================
    u_hdmi_controler : entity work.hdmi_controler
        generic map (
            h_res  => h_res,
            v_res  => v_res,
            h_sync => 61,
            h_fp   => 58,
            h_bp   => 18,
            v_sync => 5,
            v_fp   => 30,
            v_bp   => 9
        )
        port map (
            -- Horloge et reset produits par la PLL (extrait du TP)
            i_clk            => s_clk_27,
            i_rst_n          => s_rst_n,

            -- Signaux de contrôle HDMI branchés directement sur les sorties
            o_hdmi_hs        => o_hdmi_tx_hs,
            o_hdmi_vs        => o_hdmi_tx_vs,
            o_hdmi_de        => o_hdmi_tx_de,

            -- Signaux non utilisés ici (extrait du TP)
            o_pixel_en       => open,
            o_pixel_address  => open,

            -- Coordonnées pixel récupérées pour générer les couleurs
            o_x_counter      => s_x_counter,
            o_y_counter      => s_y_counter
        );

    -- =======================================================================
    -- Horloge TMDS = pixel clock (27 MHz pour le 480p)
    -- =======================================================================
    o_hdmi_tx_clk <= s_clk_27;

    -- =======================================================================
    -- Génération des pixels (extrait exact du TP)
    --   "Connectez les sorties pixel (signal o_hdmi_tx_d) aux compteurs x, y."
    --
    --   Bits 23..16 = R = x  (varie horizontalement)
    --   Bits 15..8  = G = y  (varie verticalement)
    --   Bits 7..0   = B = 0
    -- =======================================================================
    o_hdmi_tx_d(23 downto 16) <= std_logic_vector(to_unsigned(s_x_counter, 8));
    o_hdmi_tx_d(15 downto 8)  <= std_logic_vector(to_unsigned(s_y_counter, 8));
    o_hdmi_tx_d(7 downto 0)   <= (others => '0');

end architecture rtl;
